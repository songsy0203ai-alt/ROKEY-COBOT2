import numpy as np
import cv2
import json
import os
import re

class GeminiNerve:
    def __init__(self, calibration_path):
        self.calibration_path = calibration_path
        self.homography_matrix = None
        self.load_calibration()

    def load_calibration(self):
        """저장된 캘리브레이션 데이터(JSON)에서 호모그래피 행렬을 로드함"""
        if os.path.exists(self.calibration_path):
            try:
                with open(self.calibration_path, 'r') as f:
                    data = json.load(f)
                    self.homography_matrix = np.array(data['matrix'])
                print(f"성공: {self.calibration_path}에서 행렬을 로드했습니다.")
            except Exception as e:
                print(f"오류: 캘리브레이션 파일 읽기 실패 - {e}")
        else:
            print("경고: 캘리브레이션 파일이 없습니다. scripts/calib_node.py를 먼저 실행하십시오.")

    def parse_gemini_response(self, response_text):
        """
        Gemini 2.5의 JSON 응답에서 좌표와 라벨 추출
        형식: [{"point": [y, x], "label": "target"}]
        """
        try:
            # 텍스트 내 JSON 블록만 추출 (마크다운 코드 블록 제거)
            json_str = re.search(r'\[\s*\{.*\}\s*\]', response_text, re.DOTALL)
            if json_str:
                tasks = json.loads(json_str.group())
                return tasks
            return []
        except Exception as e:
            print(f"오류: JSON 파싱 실패 - {e}")
            return []

    def denormalize_pixel(self, y_norm, x_norm, img_w, img_h):
        """0~1000 정규화 좌표를 실제 이미지 픽셀 좌표로 변환"""
        # Gemini는 [y, x] 순서로 출력하므로 변환 시 주의
        real_x = (x_norm / 1000.0) * img_w
        real_y = (y_norm / 1000.0) * img_h
        return real_x, real_y

    def convert_to_robot_coords(self, y_norm, x_norm, img_w=1280, img_h=720):
        """
        Gemini 좌표(픽셀 평면)를 로봇 좌표(mm 단위 평면)로 변환
        수학적 모델: $ \begin{bmatrix} X \\ Y \\ 1 \end{bmatrix} = H \begin{bmatrix} u \\ v \\ 1 \end{bmatrix} $
        """
        if self.homography_matrix is None:
            return None

        # 1. 역정규화
        px, py = self.denormalize_pixel(y_norm, x_norm, img_w, img_h)

        # 2. 호모그래피 투영 변환
        pixel_point = np.array([[px], [py], [1.0]])
        robot_point = np.dot(self.homography_matrix, pixel_point)
        
        # 3. 동차 좌표계(Homogeneous coordinates) 정규화
        w = robot_point[2][0]
        robot_x = robot_point[0][0] / w
        robot_y = robot_point[1][0] / w

        return [robot_x, robot_y]

    def save_calibration(self, matrix):
        """측정된 호모그래피 행렬 저장"""
        self.homography_matrix = matrix
        data = {'matrix': matrix.tolist()}
        os.makedirs(os.path.dirname(self.calibration_path), exist_ok=True)
        with open(self.calibration_path, 'w') as f:
            json.dump(data, f)
        print(f"저장 완료: {self.calibration_path}")