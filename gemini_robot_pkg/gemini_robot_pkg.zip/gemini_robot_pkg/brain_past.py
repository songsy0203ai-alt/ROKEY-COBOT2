# gemini_robot_pkg/brain_past.py
# 모델에 "gemini-2.5-pro" 사용

import google.generativeai as genai

class GeminiBrain:
    def __init__(self, api_key):
        genai.configure(api_key=api_key)
        
        # 2.5 모델로 업데이트
        # 팁: 최신 기능을 위해 'gemini-2.5-pro' 또는 'gemini-3-pro' 사용 가능
        self.model_name = 'gemini-2.5-pro' 
        
        self.model = genai.GenerativeModel(
            model_name=self.model_name,
            system_instruction="""
            너는 정교한 로봇 제어를 위한 Embodied AI야. 
            이미지에서 물체를 감지하고, 해당 물체에 대한 정교한 [y, x] 포인팅 좌표를 생성해.
            특히 나사, 단자, 도구 등 미세한 부품의 상태를 읽고 추론할 수 있어.
            """
        )

    def get_robot_instruction(self, workspace_img):
        # 블로그 예시처럼 JSON 리스트 형태의 출력을 유도
        prompt = """
        이미지에서 모든 '전선 연결 단자'를 찾아서 포인팅해줘.
        답변은 [{"point": [y, x], "label": "terminal_name"}] JSON 형식을 따라야 해.
        포인트는 0~1000 값으로 정규화해줘.
        """
        response = self.model.generate_content([prompt, workspace_img])
        return response.text