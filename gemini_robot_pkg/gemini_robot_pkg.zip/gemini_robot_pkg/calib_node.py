#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
[코드 기능]
카메라 영상의 2D 픽셀 좌표(u, v)와 실제 로봇 작업 평면의 2D 좌표(x, y) 사이의 관계를 정의하는 
호모그래피(Homography) 행렬을 생성하고 저장하는 캘리브레이션 노드입니다.

[입력(Input)]
1. 사용자의 마우스 클릭: 카메라 영상 내 4개 지점의 픽셀 좌표.
2. 터미널 입력: 각 마우스 클릭 지점에 대응하는 실제 로봇의 X, Y 좌표 (mm 단위).

[출력(Output)]
1. h_matrix: 3x3 호모그래피 변환 행렬.
2. matrix.json: 계산된 행렬을 지정된 경로에 JSON 파일로 저장.
"""

import rclpy
from rclpy.node import Node
import cv2
import numpy as np
import os
from gemini_robot_pkg.nerve import GeminiNerve

class CalibNode(Node):
    def __init__(self):
        """
        CalibNode 클래스 초기화 및 경로 설정
        """
        super().__init__('calib_node')
        
        # 결과 행렬을 저장할 파일 시스템 경로 설정
        self.calib_data_path = os.path.expanduser(
            '~/cobot_ws/src/cobot2_ws/gemini_robot_pkg/data/calibration/matrix.json'
        )
        
        # 행렬 저장 및 로드를 담당하는 신경망 인터페이스 객체 생성
        self.nerve = GeminiNerve(self.calib_data_path)
        
        # 데이터 포인트 저장을 위한 리스트 초기화
        self.img_points = []    # 카메라 픽셀 좌표 (u, v)
        self.robot_points = []  # 로봇 실제 좌표 (x, y)
        
        print("--- Calibration 시작 ---")
        print("1. 카메라 창에서 대응하는 4개의 점을 순서대로 클릭하세요.")
        print("2. 클릭할 때마다 터미널에 해당 지점의 로봇 좌표(x, y)를 입력하세요.")

    def mouse_callback(self, event, x, y, flags, param):
        """
        OpenCV 마우스 이벤트 콜백 함수
        :param event: 마우스 이벤트 종류 (클릭, 이동 등)
        :param x: 클릭된 지점의 영상 내 u 좌표 (pixel)
        :param y: 클릭된 지점의 영상 내 v 좌표 (pixel)
        :param flags: 이벤트 관련 플래그
        :param param: cv2.setMouseCallback을 통해 전달된 프레임 이미지
        """
        # 마우스 왼쪽 버튼 클릭 시 동작
        if event == cv2.EVENT_LBUTTONDOWN:
            print(f"\n[점 {len(self.img_points) + 1}] 클릭된 픽셀 좌표: u={x}, v={y}")
            
            try:
                # 클릭한 픽셀에 대응하는 실제 로봇 위치를 사용자로부터 입력받음
                rx = float(input("로봇 X 좌표 (mm): "))
                ry = float(input("로봇 Y 좌표 (mm): "))
                
                # 좌표 데이터를 리스트에 추가
                self.img_points.append([x, y])
                self.robot_points.append([rx, ry])
                
                # 영상 위에 클릭 지점 시각화 (녹색 원 및 텍스트)
                cv2.circle(param, (x, y), 5, (0, 255, 0), -1)
                cv2.putText(param, f"P{len(self.img_points)}", (x+10, y+10), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
                cv2.imshow("Calibration Window", param)
                
            except ValueError:
                # 숫자가 아닌 값이 입력되었을 때 예외 처리
                print("숫자만 입력 가능합니다. 다시 시도하세요.")

    def run(self):
        """
        메인 실행 루프: 카메라를 열고 4개의 점을 획득한 후 행렬 계산
        """
        # 시스템 기본 카메라 장치 연결
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("카메라를 열 수 없습니다.")
            return

        cv2.namedWindow("Calibration Window")
        
        # 점 4개가 수집될 때까지 영상 출력 및 대기
        while len(self.img_points) < 4:
            ret, frame = cap.read()
            if not ret: break
            
            cv2.imshow("Calibration Window", frame)
            # 마우스 콜백 등록 (매 루프마다 현재 프레임을 인자로 전달)
            cv2.setMouseCallback("Calibration Window", self.mouse_callback, param=frame)
            
            # ESC 키 입력 시 강제 종료
            if cv2.waitKey(1) & 0xFF == 27:
                break

        # 4개의 대응점(Correspondence)이 모두 수집되었을 때 계산 수행
        if len(self.img_points) == 4:
            # 리스트를 numpy float32 배열로 변환
            src_pts = np.array(self.img_points, dtype=np.float32)
            dst_pts = np.array(self.robot_points, dtype=np.float32)
            
            # 카메라 평면 -> 로봇 평면으로 매핑하는 호모그래피 행렬 H 계산
            # H는 3x3 행렬로, 식은 다음과 같음: s[x, y, 1]^T = H [u, v, 1]^T
            h_matrix, _ = cv2.findHomography(src_pts, dst_pts)
            
            # 생성된 행렬을 JSON 파일로 저장
            self.nerve.save_calibration(h_matrix)
            print("\n--- Calibration 완료 및 저장 성공! ---")
            print(f"Matrix:\n{h_matrix}")
        
        cap.release()
        cv2.destroyAllWindows()

def main(args=None):
    """
    ROS2 노드 초기화 및 실행 진입점
    """
    rclpy.init(args=args)
    node = CalibNode()
    node.run()
    rclpy.shutdown()

if __name__ == '__main__':
    main()