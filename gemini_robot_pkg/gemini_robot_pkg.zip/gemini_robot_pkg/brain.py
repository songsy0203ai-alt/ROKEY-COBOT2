# gemini_robot_pkg/brain.py
# 모델에 "gemini-robotics-er-1.5-preview" 사용

from google import genai
from google.genai import types
import PIL.Image
import os

class GeminiBrain:
    def __init__(self, api_key):
        # 최신 SDK 클라이언트 생성
        self.client = genai.Client(api_key=api_key)
        
        # 모델명 지정: 공식 문서의 ER 프리뷰 모델 사용
        self.model_name = "gemini-robotics-er-1.5-preview"

    def get_next_task_point(self, circuit_img_path, workspace_img_path):
        """
        회로도와 실물 사진을 기반으로 로보틱스 특화 추론 수행
        """
        prompt = """
        너는 Doosan M0609 로봇의 두뇌야. 
        1. circuit_diagram의 결선 순서를 파악해.
        2. workspace_image에서 다음 작업 위치를 찾아.
        3. 결과를 [{"point": [y, x], "label": "target_name"}] 형식의 JSON으로만 출력해.
        포인트는 0-1000으로 정규화해줘.
        """

        # 이미지 로드
        with open(workspace_img_path, 'rb') as f:
            workspace_bytes = f.read()
        
        # API 호출 (Thinking Budget 설정 포함)
        response = self.client.models.generate_content(
            model=self.model_name,
            contents=[
                types.Part.from_bytes(data=workspace_bytes, mime_type='image/jpeg'),
                prompt
            ],
            config=types.GenerateContentConfig(
                temperature=0.5,
                # 복잡한 회로 추론을 위해 사고 과정(Thinking) 활성화
                thinking_config=types.ThinkingConfig(thinking_budget=100) 
            )
        )
        
        return response.text